package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.provider.CallLog
import android.provider.Telephony
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.*

data class CallLogEntry(
    val number: String = "",
    val type: String = "",
    val durationSeconds: Long = 0,
    val timestamp: Long = 0,
    val formattedDate: String = ""
)

data class SmsLogEntry(
    val address: String = "",
    val body: String = "",
    val type: String = "",
    val timestamp: Long = 0,
    val formattedDate: String = ""
)

/**
 * Foreground Service for syncing Call and SMS logs to Firebase Realtime Database.
 */
class CallSmsService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val TAG = "CallSmsService"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val sharedUid = intent?.getStringExtra("SHARED_UID") ?: "default_uid"
        val deviceId = intent?.getStringExtra("DEVICE_ID") ?: getDeviceId(this)

        Log.d(TAG, "Starting sync for parent Shared UID: $sharedUid, Device ID: $deviceId")

        serviceScope.launch {
            syncCallLogs(sharedUid, deviceId)
            syncSmsLogs(sharedUid, deviceId)
        }

        return START_STICKY
    }

    private fun syncCallLogs(sharedUid: String, deviceId: String) {
        try {
            val cursor = contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER,
                    CallLog.Calls.TYPE,
                    CallLog.Calls.DURATION,
                    CallLog.Calls.DATE
                ),
                null, null, CallLog.Calls.DATE + " DESC LIMIT 50"
            )

            val callList = mutableListOf<Map<String, Any>>()
            cursor?.use { c ->
                val numIdx = c.getColumnIndex(CallLog.Calls.NUMBER)
                val typeIdx = c.getColumnIndex(CallLog.Calls.TYPE)
                val durIdx = c.getColumnIndex(CallLog.Calls.DURATION)
                val dateIdx = c.getColumnIndex(CallLog.Calls.DATE)

                while (c.moveToNext()) {
                    val number = if (numIdx != -1) c.getString(numIdx) ?: "Unknown" else "Unknown"
                    val typeInt = if (typeIdx != -1) c.getInt(typeIdx) else 0
                    val duration = if (durIdx != -1) c.getLong(durIdx) else 0L
                    val timestamp = if (dateIdx != -1) c.getLong(dateIdx) else 0L

                    val typeStr = when (typeInt) {
                        CallLog.Calls.INCOMING_TYPE -> "Incoming"
                        CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
                        CallLog.Calls.MISSED_TYPE -> "Missed"
                        CallLog.Calls.REJECTED_TYPE -> "Rejected"
                        else -> "Other"
                    }

                    val dateFormatted = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                        .format(java.util.Date(timestamp))

                    val item = mapOf(
                        "number" to number,
                        "type" to typeStr,
                        "durationSeconds" to duration,
                        "timestamp" to timestamp,
                        "formattedDate" to dateFormatted
                    )
                    callList.add(item)
                }
            }

            if (callList.isNotEmpty()) {
                val dbRef = FirebaseDatabase.getInstance().reference
                    .child("parents")
                    .child(sharedUid)
                    .child("devices")
                    .child(deviceId)
                    .child("call_logs")

                dbRef.setValue(callList)
                    .addOnSuccessListener { Log.d(TAG, "Call logs synced successfully") }
                    .addOnFailureListener { e -> Log.e(TAG, "Failed to sync call logs: ${e.message}") }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying Call Log permission or database: ${e.message}")
        }
    }

    private fun syncSmsLogs(sharedUid: String, deviceId: String) {
        try {
            val cursor = contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(
                    Telephony.Sms.ADDRESS,
                    Telephony.Sms.BODY,
                    Telephony.Sms.TYPE,
                    Telephony.Sms.DATE
                ),
                null, null, Telephony.Sms.DATE + " DESC LIMIT 50"
            )

            val smsList = mutableListOf<Map<String, Any>>()
            cursor?.use { c ->
                val addrIdx = c.getColumnIndex(Telephony.Sms.ADDRESS)
                val bodyIdx = c.getColumnIndex(Telephony.Sms.BODY)
                val typeIdx = c.getColumnIndex(Telephony.Sms.TYPE)
                val dateIdx = c.getColumnIndex(Telephony.Sms.DATE)

                while (c.moveToNext()) {
                    val address = if (addrIdx != -1) c.getString(addrIdx) ?: "Unknown" else "Unknown"
                    val body = if (bodyIdx != -1) c.getString(bodyIdx) ?: "" else ""
                    val typeInt = if (typeIdx != -1) c.getInt(typeIdx) else 0
                    val timestamp = if (dateIdx != -1) c.getLong(dateIdx) else 0L

                    val typeStr = when (typeInt) {
                        Telephony.Sms.MESSAGE_TYPE_INBOX -> "Received"
                        Telephony.Sms.MESSAGE_TYPE_SENT -> "Sent"
                        Telephony.Sms.MESSAGE_TYPE_DRAFT -> "Draft"
                        else -> "Other"
                    }

                    val dateFormatted = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault())
                        .format(java.util.Date(timestamp))

                    val item = mapOf(
                        "address" to address,
                        "body" to body,
                        "type" to typeStr,
                        "timestamp" to timestamp,
                        "formattedDate" to dateFormatted
                    )
                    smsList.add(item)
                }
            }

            if (smsList.isNotEmpty()) {
                val dbRef = FirebaseDatabase.getInstance().reference
                    .child("parents")
                    .child(sharedUid)
                    .child("devices")
                    .child(deviceId)
                    .child("sms_logs")

                dbRef.setValue(smsList)
                    .addOnSuccessListener { Log.d(TAG, "SMS logs synced successfully") }
                    .addOnFailureListener { e -> Log.e(TAG, "Failed to sync SMS logs: ${e.message}") }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying SMS Log permission or database: ${e.message}")
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Child Guardian Service")
            .setContentText("Parent monitoring active")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Child Guardian Active Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    companion object {
        private const val CHANNEL_ID = "child_guardian_service_channel"
        private const val NOTIFICATION_ID = 2001

        fun getDeviceId(context: Context): String {
            val prefs = context.getSharedPreferences("child_guardian_prefs", Context.MODE_PRIVATE)
            var deviceId = prefs.getString("device_id", null)
            if (deviceId == null) {
                deviceId = "device_" + java.util.UUID.randomUUID().toString().take(8)
                prefs.edit().putString("device_id", deviceId).apply()
            }
            return deviceId
        }
    }
}
