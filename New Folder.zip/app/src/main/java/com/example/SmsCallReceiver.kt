package com.example

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * BroadcastReceiver listening for real-time incoming SMS broadcasts
 * and re-triggering the CallSmsService sync.
 */
class SmsCallReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == "android.provider.Telephony.SMS_RECEIVED") {
            val prefs = context.getSharedPreferences("child_guardian_prefs", Context.MODE_PRIVATE)
            val sharedUid = prefs.getString("shared_uid", null) ?: return
            val deviceId = CallSmsService.getDeviceId(context)

            val serviceIntent = Intent(context, CallSmsService::class.java).apply {
                putExtra("SHARED_UID", sharedUid)
                putExtra("DEVICE_ID", deviceId)
            }

            try {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    context.startForegroundService(serviceIntent)
                } else {
                    context.startService(serviceIntent)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
