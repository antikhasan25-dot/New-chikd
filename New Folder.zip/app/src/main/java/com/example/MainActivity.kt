package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.CallLog
import android.provider.Telephony
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.MyApplicationTheme
import com.google.firebase.auth.FirebaseAuth
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {

    private lateinit var deviceAdminManager: DeviceAdminManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        deviceAdminManager = DeviceAdminManager(this)

        setContent {
            MyApplicationTheme {
                MainDashboardScreen(
                    deviceAdminManager = deviceAdminManager,
                    onLogout = {
                        val prefs = getSharedPreferences("child_guardian_prefs", Context.MODE_PRIVATE)
                        prefs.edit().clear().apply()
                        try {
                            FirebaseAuth.getInstance().signOut()
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                        val authIntent = Intent(this@MainActivity, AuthActivity::class.java)
                        startActivity(authIntent)
                        finish()
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // Prompt for device admin on setup if missing
        if (!deviceAdminManager.isAdminActive()) {
            Toast.makeText(this, "Device Admin Permission recommended for Child Guardian", Toast.LENGTH_SHORT).show()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboardScreen(
    deviceAdminManager: DeviceAdminManager,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("child_guardian_prefs", Context.MODE_PRIVATE) }

    val currentAuthUid = remember { try { FirebaseAuth.getInstance().currentUser?.uid } catch (e: Exception) { null } }
    var sharedUid by remember { mutableStateOf(currentAuthUid ?: prefs.getString("shared_uid", "parent_uid_98765") ?: "parent_uid_98765") }
    val deviceId = remember { CallSmsService.getDeviceId(context) }

    var isAdminActive by remember { mutableStateOf(deviceAdminManager.isAdminActive()) }
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Calls, 1: SMS, 2: Sync Status, 3: Protection

    var callLogs by remember { mutableStateOf<List<CallLogEntry>>(emptyList()) }
    var smsLogs by remember { mutableStateOf<List<SmsLogEntry>>(emptyList()) }
    var isSyncing by remember { mutableStateOf(false) }
    var lastSyncTime by remember { mutableStateOf("Just now") }

    // Required Runtime Permissions
    val requiredPermissions = remember {
        val permissions = mutableListOf(
            Manifest.permission.READ_CALL_LOG,
            Manifest.permission.READ_SMS,
            Manifest.permission.RECEIVE_SMS
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissions.toTypedArray()
    }

    fun checkPermissionsGranted(): Boolean {
        return requiredPermissions.all {
            ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
        }
    }

    var permissionsGranted by remember { mutableStateOf(checkPermissionsGranted()) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        permissionsGranted = results.values.all { it }
        if (permissionsGranted) {
            Toast.makeText(context, "Permissions Granted! Refreshing logs...", Toast.LENGTH_SHORT).show()
        }
    }

    val adminLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        isAdminActive = deviceAdminManager.isAdminActive()
    }

    // Function to reload logs locally for display
    fun reloadLogs() {
        if (!permissionsGranted) return

        isSyncing = true
        // Read Calls
        try {
            val callList = mutableListOf<CallLogEntry>()
            val cCursor = context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(
                    CallLog.Calls.NUMBER,
                    CallLog.Calls.TYPE,
                    CallLog.Calls.DURATION,
                    CallLog.Calls.DATE
                ),
                null, null, CallLog.Calls.DATE + " DESC LIMIT 50"
            )
            cCursor?.use { c ->
                val numIdx = c.getColumnIndex(CallLog.Calls.NUMBER)
                val typeIdx = c.getColumnIndex(CallLog.Calls.TYPE)
                val durIdx = c.getColumnIndex(CallLog.Calls.DURATION)
                val dateIdx = c.getColumnIndex(CallLog.Calls.DATE)

                while (c.moveToNext()) {
                    val num = if (numIdx != -1) c.getString(numIdx) ?: "Unknown" else "Unknown"
                    val typeInt = if (typeIdx != -1) c.getInt(typeIdx) else 0
                    val dur = if (durIdx != -1) c.getLong(durIdx) else 0L
                    val time = if (dateIdx != -1) c.getLong(dateIdx) else 0L

                    val typeStr = when (typeInt) {
                        CallLog.Calls.INCOMING_TYPE -> "Incoming"
                        CallLog.Calls.OUTGOING_TYPE -> "Outgoing"
                        CallLog.Calls.MISSED_TYPE -> "Missed"
                        CallLog.Calls.REJECTED_TYPE -> "Rejected"
                        else -> "Other"
                    }

                    val dateFmt = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(time))
                    callList.add(CallLogEntry(num, typeStr, dur, time, dateFmt))
                }
            }
            callLogs = callList
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Read SMS
        try {
            val smsList = mutableListOf<SmsLogEntry>()
            val sCursor = context.contentResolver.query(
                Telephony.Sms.CONTENT_URI,
                arrayOf(
                    Telephony.Sms.ADDRESS,
                    Telephony.Sms.BODY,
                    Telephony.Sms.TYPE,
                    Telephony.Sms.DATE
                ),
                null, null, Telephony.Sms.DATE + " DESC LIMIT 50"
            )
            sCursor?.use { c ->
                val addrIdx = c.getColumnIndex(Telephony.Sms.ADDRESS)
                val bodyIdx = c.getColumnIndex(Telephony.Sms.BODY)
                val typeIdx = c.getColumnIndex(Telephony.Sms.TYPE)
                val dateIdx = c.getColumnIndex(Telephony.Sms.DATE)

                while (c.moveToNext()) {
                    val addr = if (addrIdx != -1) c.getString(addrIdx) ?: "Unknown" else "Unknown"
                    val body = if (bodyIdx != -1) c.getString(bodyIdx) ?: "" else ""
                    val typeInt = if (typeIdx != -1) c.getInt(typeIdx) else 0
                    val time = if (dateIdx != -1) c.getLong(dateIdx) else 0L

                    val typeStr = when (typeInt) {
                        Telephony.Sms.MESSAGE_TYPE_INBOX -> "Received"
                        Telephony.Sms.MESSAGE_TYPE_SENT -> "Sent"
                        else -> "Draft/Other"
                    }

                    val dateFmt = SimpleDateFormat("MMM dd, HH:mm", Locale.getDefault()).format(Date(time))
                    smsList.add(SmsLogEntry(addr, body, typeStr, time, dateFmt))
                }
            }
            smsLogs = smsList
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Trigger Service Sync
        val serviceIntent = Intent(context, CallSmsService::class.java).apply {
            putExtra("SHARED_UID", sharedUid)
            putExtra("DEVICE_ID", deviceId)
        }
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        lastSyncTime = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        isSyncing = false
    }

    LaunchedEffect(permissionsGranted) {
        if (permissionsGranted) {
            reloadLogs()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Child Guardian Dashboard",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                        Text(
                            text = "Parent Shared UID: $sharedUid",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { reloadLogs() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Sync Now")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                )
            )
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Call, contentDescription = null) },
                    label = { Text("Call History") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Sms, contentDescription = null) },
                    label = { Text("SMS Logs") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.CloudSync, contentDescription = null) },
                    label = { Text("Firebase Sync") }
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Security, contentDescription = null) },
                    label = { Text("Protection") }
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {

            // Device Admin Banner Alert if not active
            if (!isAdminActive) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Device Admin Disabled",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                            Text(
                                text = "Enable Device Admin to prevent unauthorized app removal.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onErrorContainer
                            )
                        }
                        Button(
                            onClick = {
                                adminLauncher.launch(deviceAdminManager.getAddDeviceAdminIntent())
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Activate")
                        }
                    }
                }
            }

            // Permission Request Card if missing permissions
            if (!permissionsGranted) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Call & SMS Permissions Required",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Child Guardian requires access to Call Logs and SMS messages to log and synchronize data.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { permissionLauncher.launch(requiredPermissions) },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text("Grant All Permissions")
                        }
                    }
                }
            }

            // Tab Content
            Box(modifier = Modifier.weight(1f)) {
                when (selectedTab) {
                    0 -> CallLogsTab(callLogs, permissionsGranted) { reloadLogs() }
                    1 -> SmsLogsTab(smsLogs, permissionsGranted) { reloadLogs() }
                    2 -> SyncStatusTab(sharedUid, deviceId, lastSyncTime, callLogs.size, smsLogs.size) { reloadLogs() }
                    3 -> ProtectionTab(
                        isAdminActive = isAdminActive,
                        sharedUid = sharedUid,
                        deviceId = deviceId,
                        onActivateAdmin = { adminLauncher.launch(deviceAdminManager.getAddDeviceAdminIntent()) },
                        onUpdateSharedUid = { newUid ->
                            sharedUid = newUid
                            prefs.edit().putString("shared_uid", newUid).apply()
                            reloadLogs()
                        },
                        onLogout = onLogout
                    )
                }
            }
        }
    }
}

@Composable
fun CallLogsTab(
    logs: List<CallLogEntry>,
    hasPermission: Boolean,
    onRefresh: () -> Unit
) {
    if (!hasPermission) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Grant Call Log permissions to view and sync call history.")
        }
        return
    }

    if (logs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.PhoneCallback, contentDescription = null, modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text("No Call Logs found or synced.")
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = onRefresh) { Text("Scan Call Logs") }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(logs) { log ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val icon = when (log.type) {
                        "Incoming" -> Icons.Default.CallReceived
                        "Outgoing" -> Icons.Default.CallMade
                        "Missed" -> Icons.Default.CallMissed
                        else -> Icons.Default.Phone
                    }
                    val iconColor = when (log.type) {
                        "Incoming" -> Color(0xFF2E7D32)
                        "Outgoing" -> Color(0xFF1565C0)
                        "Missed" -> Color(0xFFC62828)
                        else -> MaterialTheme.colorScheme.primary
                    }

                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(iconColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon, contentDescription = null, tint = iconColor)
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = log.number, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(
                            text = "${log.type} • ${log.durationSeconds}s duration",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = log.formattedDate,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
fun SmsLogsTab(
    logs: List<SmsLogEntry>,
    hasPermission: Boolean,
    onRefresh: () -> Unit
) {
    if (!hasPermission) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Grant SMS permissions to view and sync SMS messages.")
        }
        return
    }

    if (logs.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.SmsFailed, contentDescription = null, modifier = Modifier.size(48.dp))
                Spacer(modifier = Modifier.height(8.dp))
                Text("No SMS logs found or synced.")
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = onRefresh) { Text("Scan SMS Logs") }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(logs) { log ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (log.type == "Received") Icons.Default.Inbox else Icons.Default.Send,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp),
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = log.address,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp
                            )
                        }

                        Text(
                            text = log.formattedDate,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = log.body,
                        fontSize = 13.sp,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

@Composable
fun SyncStatusTab(
    sharedUid: String,
    deviceId: String,
    lastSyncTime: String,
    callCount: Int,
    smsCount: Int,
    onForceSync: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CloudUpload,
                        contentDescription = null,
                        modifier = Modifier.size(32.dp),
                        tint = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Firebase Realtime DB Sync",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Status: Active Monitoring Service Running",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                HorizontalDivider(color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f))

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Firebase Database Target Path:",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
                Text(
                    text = "/parents/$sharedUid/devices/$deviceId/",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.primary
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Last Synced: $lastSyncTime",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = callCount.toString(), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Call Logs Synced", fontSize = 12.sp)
                }
            }

            Card(
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = smsCount.toString(), fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(text = "SMS Logs Synced", fontSize = 12.sp)
                }
            }
        }

        Button(
            onClick = onForceSync,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Sync, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("FORCE IMMEDIATE FIREBASE SYNC")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProtectionTab(
    isAdminActive: Boolean,
    sharedUid: String,
    deviceId: String,
    onActivateAdmin: () -> Unit,
    onUpdateSharedUid: (String) -> Unit,
    onLogout: () -> Unit
) {
    var newUid by remember { mutableStateOf(sharedUid) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Anti-Uninstall & System Protection",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Device Admin Permission", fontWeight = FontWeight.SemiBold)
                        Text(
                            text = if (isAdminActive) "Active Protection Enabled" else "Not Granted",
                            fontSize = 12.sp,
                            color = if (isAdminActive) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                    }

                    if (!isAdminActive) {
                        Button(onClick = onActivateAdmin) {
                            Text("Enable")
                        }
                    } else {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color(0xFF2E7D32)
                        )
                    }
                }
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "Parent Shared UID Settings",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = newUid,
                    onValueChange = { newUid = it },
                    label = { Text("Shared Parent UID") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = { onUpdateSharedUid(newUid.trim()) },
                    modifier = Modifier.align(Alignment.End)
                ) {
                    Text("Save Shared UID")
                }
            }
        }

        Spacer(modifier = Modifier.weight(1f))

        OutlinedButton(
            onClick = onLogout,
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
        ) {
            Icon(Icons.Default.Logout, contentDescription = null)
            Spacer(modifier = Modifier.width(8.dp))
            Text("LOGOUT PARENT ACCOUNT")
        }
    }
}
