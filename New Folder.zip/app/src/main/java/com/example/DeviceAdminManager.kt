package com.example

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent

/**
 * Manager to handle Device Admin activation and status checks.
 * Prevents unauthorized uninstallation from Android device settings.
 */
class DeviceAdminManager(private val context: Context) {

    private val devicePolicyManager: DevicePolicyManager =
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    val compName: ComponentName = ComponentName(context, MyDeviceAdminReceiver::class.java)

    /**
     * Checks if Device Admin permission is currently active.
     */
    fun isAdminActive(): Boolean {
        return devicePolicyManager.isAdminActive(compName)
    }

    /**
     * Returns an intent to prompt the user to grant Device Admin permission.
     */
    fun getAddDeviceAdminIntent(): Intent {
        val intent = Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, compName)
        intent.putExtra(
            DevicePolicyManager.EXTRA_ADD_EXPLANATION,
            "Child Guardian requires Device Admin activation to protect system background monitoring and prevent unauthorized app uninstallation."
        )
        return intent
    }

    /**
     * Prompts the user to activate Device Admin permission from an Activity context.
     */
    fun promptEnableAdmin(activity: Activity, requestCode: Int = 1001) {
        if (!isAdminActive()) {
            val intent = getAddDeviceAdminIntent()
            activity.startActivityForResult(intent, requestCode)
        }
    }
}
